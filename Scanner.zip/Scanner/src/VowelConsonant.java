import java.util.Scanner;
// Enter any value and the find out if it is Vowel or Consonant, depending on the user input.
public class VowelConsonant {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // User can enter any alphabet from A to Z
        System.out.println("Please enter a character");
        String value = scanner.next();

        if (value.equals("A") || value.equals("E") || value.equals("I") || value.equals("O") || value.equals("U")) {
            System.out.println("This is Vowel");
            } else if (value.equals("a") || value.equals("e") || value.equals("i") || value.equals("o") || value.equals("u")) {
                System.out.println("This is Vowel");
            } else System.out.println("This is Consonant");
            }
        }

